just added some comment in the readme for slack testing 
